namespace Hmaburgueria_MVC.Models
{
    public class Shake
    {
        public string Nome {get;set;}
    }
}